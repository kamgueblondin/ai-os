#!/bin/sh
echo 'Script de demarrage AI-OS v5.0'
