#!/bin/sh
echo 'Script de demarrage AI-OS'
